/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo;

import cjb.ci.Mensajes;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JFrame;

/**
 *
 * @author Fernanda
 */
public class Archivos
{
     public static void guarda(JFrame jf, Object obj, String s)
    {
        try
        {
            FileOutputStream fos = new FileOutputStream(s);
            ObjectOutputStream arch = new ObjectOutputStream(fos);
            arch.writeObject(obj);
            arch.close();
            Mensajes.exito(jf, "Archivo guardado exitosamente"); // <- Cambiado de "cargado" a "guardado"
        } catch (java.io.FileNotFoundException ex)
        {
            Mensajes.error(jf, "Archivo no encontrado...");
        } catch (Exception ex)
        {
            Mensajes.error(jf, "Error..." + ex.toString());
        }
    } 

    public static void guarda(JFrame jf, Object obj[], String s)
    {
        try
        {
            FileOutputStream fos = new FileOutputStream(s);
            ObjectOutputStream arch = new ObjectOutputStream(fos);
            arch.writeObject(obj);
            arch.close();
            Mensajes.exito(jf, "Archivo guardado exitosamente"); // <- Cambiado de "cargado" a "guardado"
        } catch (java.io.FileNotFoundException ex)
        {
            Mensajes.error(jf, "Archivo no encontrado...");
        } catch (Exception ex)
        {
            Mensajes.error(jf, "Error..." + ex.toString());
        }
    }

    public static Object carga(JFrame jf, String s)
    {
        Object obj = null;
        try
        {
            FileInputStream fis = new FileInputStream(s); // <- Cambiado de "fos" a "fis"
            ObjectInputStream arch = new ObjectInputStream(fis);
            obj = arch.readObject();
            arch.close();
            Mensajes.exito(jf, "Archivo cargado exitosamente"); // <- Este mensaje está correcto
        } catch (FileNotFoundException ex)
        {
            Mensajes.error(jf, "Archivo no encontrado");
        } catch (Exception ex)
        {
            Mensajes.error(jf, "Error..." + ex.toString());
        }
        return obj;
    }

    public static Object[] cargaArr(JFrame jf, String s)
    {
        Object obj[] = null;
        try
        {
            FileInputStream fis = new FileInputStream(s); // <- Cambiado de "fos" a "fis"
            ObjectInputStream arch = new ObjectInputStream(fis);
            obj = (Object[]) arch.readObject();
            arch.close();
            Mensajes.exito(jf, "Archivo cargado exitosamente"); // <- Cambiado de "guardado" a "cargado"
        } catch (FileNotFoundException ex)
        {
            Mensajes.error(jf, "Archivo no encontrado");
        } catch (Exception ex)
        {
            Mensajes.error(jf, "Error..." + ex.toString());
        }
        return obj;
    }
}

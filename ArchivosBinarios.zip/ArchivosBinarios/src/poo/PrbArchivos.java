/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo;

/**
 *
 * @author Fernanda
 */
public class PrbArchivos
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
       Archivos.guarda(null,35723,"datos.dat");
        int x = (int)Archivos.carga(null, "datos.dat");
        System.out.println(x);
    }
    
}
